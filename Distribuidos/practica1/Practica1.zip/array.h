int init (char *nombre, int N);
int set (char *nombre, int i, int valor);
int get (char *nombre, int i, int *valor);
int destroy (char *nombre);